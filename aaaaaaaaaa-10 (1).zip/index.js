const { exec } = require("child_process");
exec("bash main.sh")